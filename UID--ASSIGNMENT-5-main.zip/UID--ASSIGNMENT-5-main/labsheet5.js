// Question 1: Print the Pattern
document.getElementById("q1-output").textContent = "*\n**\n***";

// Question 2: Factorial of a Number
function factorial(num) {
    if (num === 0 || num === 1) return 1;
    let result = 1;
    for (let i = 2; i <= num; i++) result *= i;
    return result;
}
let number = parseInt(prompt("Enter a number to calculate its factorial:"));
let factResult = factorial(number);
document.getElementById("q2-output").textContent = `Factorial of ${number} is ${factResult}`;

// Question 3: Capitalize First Letter of All Words (User Input)
function capitalizeWords() {
    let sentence = document.getElementById("q3-input").value;
    if (sentence) {
        let result = sentence
            .split(" ")
            .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
            .join(" ");
        document.getElementById("q3-output").textContent = result;
    } else {
        document.getElementById("q3-output").textContent = "Please enter a sentence.";
    }
}

// Question 4: Categorize Temperature (User Input)
function categorizeTemperature() {
    let temp = parseFloat(document.getElementById("q4-input").value);
    if (!isNaN(temp)) {
        let category;
        if (temp < 0) category = "Freezing";
        else if (temp >= 0 && temp <= 15) category = "Cold";
        else if (temp >= 16 && temp <= 30) category = "Moderate";
        else category = "Hot";
        document.getElementById("q4-output").textContent = `Temperature ${temp}°C is ${category}`;
    } else {
        document.getElementById("q4-output").textContent = "Please enter a valid temperature.";
    }
}

// Question 5: Days Until Next New Year
function daysUntilNewYear() {
    let today = new Date();
    let nextNewYear = new Date(today.getFullYear() + 1, 0, 1);
    let diffInTime = nextNewYear - today;
    let diffInDays = Math.ceil(diffInTime / (1000 * 60 * 60 * 24));
    return diffInDays;
}
document.getElementById("q5-output").textContent = `Days until next New Year: ${daysUntilNewYear()}`;

// Question 6: Print Current Date in Format
function formatCurrentDate() {
    let today = new Date();
    let day = today.getDate();
    let month = today.toLocaleString('default', { month: 'long' });
    let year = today.getFullYear();
    return `Today's date is: ${day} ${month} ${year}`;
}
document.getElementById("q6-output").textContent = formatCurrentDate();

// Question 7: Find Index of "locate" in String
let str = "Please locate where 'locate' occurs!";
let firstIndex = str.indexOf("locate");
let lastIndex = str.lastIndexOf("locate");
document.getElementById("q7-output").innerHTML = 
    `First occurrence of 'locate' at index: ${firstIndex}<br>Last occurrence of 'locate' at index: ${lastIndex}`;

// Question 8: Random Number and Fibonacci Numbers
function getFibonacciBelow(num) {
    let fib = [0, 1];
    while (true) {
        let nextFib = fib[fib.length - 1] + fib[fib.length - 2];
        if (nextFib >= num) break;
        fib.push(nextFib);
    }
    return fib;
}
let randomNum = Math.floor(Math.random() * 10) + 1;
let fibNumbers = getFibonacciBelow(randomNum);
document.getElementById("q8-output").innerHTML = 
    `Random number: ${randomNum}<br>Fibonacci numbers below ${randomNum}: ${fibNumbers.join(", ")}`;

// Question 9: Highest Value in Array (User Input)
function findHighest() {
    let input = document.getElementById("q9-input").value;
    let numbers = input.split(",").map(num => parseFloat(num.trim()));
    if (numbers.every(num => !isNaN(num))) {
        let highest = Math.max(...numbers);
        document.getElementById("q9-output").textContent = `Highest value in array: ${highest}`;
    } else {
        document.getElementById("q9-output").textContent = "Please enter valid numbers (e.g., 4,2,9).";
    }
}

// Question 10: Book Object with Conditions
let books = [
    { title: "The Story of My Experiments with Truth", author: "Mahatma Gandhi", cost: 600 },
    { title: "To Kill a Mockingbird", author: "Harper Lee", cost: 400 },
    { title: "Hind Swaraj", author: "Mahatma Gandhi", cost: 700 },
    { title: "1984", author: "George Orwell", cost: 300 }
];
let costOutput = "<b>Books with cost > 500:<br></b>" + 
    books
        .filter(book => book.cost > 500)
        .map(book => `${book.title}: ${book.cost}`)
        .join("<br>");
let authorOutput = "<br><b>Books by Mahatma Gandhi:<br></b>" + 
    books
        .filter(book => book.author === "Mahatma Gandhi")
        .map(book => book.title)
        .join("<br>");
document.getElementById("q10-output").innerHTML = costOutput + authorOutput;